[![goreleaser](https://github.com/CCV-Group/lambda-ecr-image-sync/actions/workflows/go.yml/badge.svg)](https://github.com/CCV-Group/lambda-ecr-image-sync/actions/workflows/go.yml)
# ecr-image-sync

GO Lambda function to compare images between ecr and dockerhub , creates a csv to s3 bucket with missing images,tags to be synced. \
based on https://github.com/pgarbe/cdk-ecr-sync

Function will compare the given images and tags between ecr and dockerhub and places the missing images in a csv file on s3 \
for a codepipelne to be picked up and pull push the missing images from the csv.


## usage

Create a lambda function using the main.zip and set runtime at go1.x.`\
Set environment variables in the lambda configuration section. \
https://github.com/martijnvdp/terraform-ecr-image-sync

variables:
```
AWS_ACCOUNT_ID='12345'
AWS_REGION='eu-west-1'
BUCKET_NAME='bucket_name'
REPO_PREFIX='global_ecr_repo_prefix' \\optional
IMAGES='[
  {
  "exclude_tags":[],
  "image_name":"hashicorp/tfc-agent",
  "include_tags":["latest"],
  "repo_prefix":"ecr/cm"
  },{
  "exclude_tags":[],
  "image_name":"datadog/agent",
  "include_tags":["latest","6.27.0-rc.6"],
  "repo_prefix":"ecr/cm"
  }]'

```

## build

```
go get github.com/aws/aws-lambda-go/lambda
GOOS=linux go build main.go

zip function.zip main
```

## zip tool
```
go.exe get -u github.com/aws/aws-lambda-go/cmd/build-lambda-zip
```

## test
Before testing aws functions make sure the aws environment vars are set.
```
 go test -v .\pkg\handlers
```

## refs
https://docs.aws.amazon.com/lambda/latest/dg/golang-package.html \
https://github.com/pgarbe/cdk-ecr-sync
